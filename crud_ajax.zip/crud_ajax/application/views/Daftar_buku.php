<!DOCTYPE html>
<html>
<head>
	<title>Daftar Buku</title>

	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/datatables/css/dataTables.bootstrap.css">
</head>
<body>

<div class="container">
	<h1>Book Store</h1>
	<h3>Daftar Buku</h3> 
	<button type="button" class="btn btn-success" onclick="add_book()">Tambah Buku</button>
	<br>
	<br> 

	<table id="table_book" class="table table-stripped table-bordered">
		<thead align="center">
			<th>ID Buku</th>
			<th>Judul Buku</th>
			<th>Author</th>
			<th>Kategori</th>
			<th>Harga Buku</th>
			<th>Action</th>
		</thead>
		<tbody align="center">
		<?php
			foreach ($books as $book ) { //foreach berfungsi untuk menampilkan data yang ada di dalam database
		?>

		<tr>
			<td align="left"><?php echo $book -> id_lb;?></td>
			<td><?php echo $book -> title;?></td>
			<td><?php echo $book -> author;?></td>
			<td><?php echo $book -> category;?></td>
			<td><?php echo $book -> price;?></td>
			<td>
				<button type="button" class="btn btn-info" onclick="edit_book(<?php echo $book -> id_lb; ?>)">EDIT</button>
				||
				<button type="button" class="btn btn-danger" onclick="delete_book(<?php echo $book -> id_lb; ?>)">DELETE</button>
			</td>
		</tr>

		<?php
		}
		?>
		<!--end of get database data -->
		</tbody>
	</table>
</div>












<!-- LINK TO JS -->
<script src="assets/jquery/jquery-3.3.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/datatables/js/dataTables.bootstrap.js"></script>
<script src="assets/datatables/js/jquery.dataTables.min.js"></script>

<!-- JS -->
<script type="text/javascript">
	$(document).ready(function(){
		$('#table_book').DataTable();//table_book adalah table yang sudah di inisiasi sebelumnya dengan id="table_book"
	});//untuk menampilkan search dan paging

	var save_method; 
	var table;


	function add_book(){
		save_method = 'add';
		$('#form')[0].reset();
		$('#modal_form').modal('show');

	}


	function save(){//fungsi untuk menyimpan data ke dalam database
		var url;

		if(save_method == 'add'){
			url = '<?php echo site_url('index.php/Book/book_add');?>';
		}else{
			url = '<?php echo site_url('index.php/Book/book_update');?>';
		}

		$.ajax({//fungsi ajax untuk mendinamis kan data
			url: url,
			type: "POST",
			data: $('#form').serialize(),
			dataType: "JSON",
			success: function(data){
				$('#modal_form').modal('hide');
				location.reload();
			},
			error: function(jqXHR, textStatus, errorThrown){
				alert("Menambah / Mengupdate Error");
			}
		});
	}


	function edit_book(id){
		save_method = "update";
		$('#form')[0].reset();

		//load data dari ajax
		$.ajax({
			url: "<?php echo site_url('index.php/Book/book_edit/'); ?>/"+id,
			type: "GET",
			dataType: "JSON",
			success: function(data){
				$('[name="id_lb"]').val(data.id_lb);
				$('[name="title"]').val(data.title);
				$('[name="author"]').val(data.author);
				$('[name="category"]').val(data.category);
				$('[name="price"]').val(data.price);

				$('#modal_form').modal('show');
				$('. modal_title').text("EDIT BOOK");
			},
			error: function(jqXHR, textStatus,errorThrown){
				alert('Gagal mengambil data dari AJAX');
			}
		})
	}


	function delete_book(id){
		if(confirm("Are you sure delete this data?")){
			//ajax delete dari database

			$.ajax({
			 url: "<?php echo site_url('index.php/Book/book_delete');?>/"+id,
			 type: "POST",
			 dataType: "JSON",
			 success: function(data){
			 	location.reload();
			 },
			error: function(jqXHR,textStatus,errorThrown){
				alert('Gagal menghapus data');
			}
			});
		}
	}

</script> 


 <!-- Modal -->
  <div class="modal fade" id="modal_form" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-header">
        <h4 class="modal-title">Tambah Buku</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
       	</div>

        <div class="modal-body form">

        <form action="#" id="form">
        	<input type="hidden" name="book_id" value="">
 
        	<div class="form-body">
        		<div class="form-group">
        			<label class="control-label col-md-3">ID:</label>
        			<div class="col-md-10">
        				<input type="text" name="id_lb" placeholder="KOSONGKAN" class="form-control">
        			</div>
        		</div>
        	</div>

        	<div class="form-body">
        		<div class="form-group">
        			<label class="control-label col-md-3">Judul:</label>
        			<div class="col-md-10">
        				<input type="text" name="title" placeholder="Judul" class="form-control">
        			</div>
        		</div>
        	</div>

		<div class="form-body">
        		<div class="form-group"> 
        			<label class="control-label col-md-3">Author:</label>
        			<div class="col-md-10">
        				<input type="text" name="author" placeholder="Author" class="form-control">
        			</div>
        		</div>
        	</div>

        	<div class="form-body">
        		<div class="form-group">
        			<label class="control-label col-md-3">Category:</label>
        			<div class="col-md-10">
        				<input type="text" name="category" placeholder="Category" class="form-control">
        			</div>
        		</div>
        	</div>

        	<div class="form-body">
        		<div class="form-group">
        			<label class="control-label col-md-3">Price:</label>
        			<div class="col-md-10">
        				<input type="text" name="price" placeholder="Price" class="form-control">
        			</div>
        		</div>
        	</div>


        </form>

         
        </div>
        <!--Button yang sudah di config di function JS (KONFIGURASINYA ADA DI FUNCTION JS)-->
        <div class="modal-footer">
       
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" onclick="save()">Simpan</button>
        </div>
      </div>
      
    </div>
  </div>




</body>
</html>